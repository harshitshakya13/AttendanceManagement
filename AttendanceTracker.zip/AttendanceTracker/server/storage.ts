import { 
  users, 
  classes, 
  enrollments, 
  attendanceRecords,
  type User, 
  type InsertUser,
  type Class,
  type InsertClass,
  type Enrollment,
  type InsertEnrollment,
  type AttendanceRecord,
  type InsertAttendanceRecord
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, count, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<void>;
  
  // Class operations
  getClasses(): Promise<Class[]>;
  getClassesByTeacher(teacherId: number): Promise<Class[]>;
  getClassesByStudent(studentId: number): Promise<Class[]>;
  createClass(classData: InsertClass): Promise<Class>;
  getClass(id: number): Promise<Class | undefined>;
  
  // Enrollment operations
  enrollStudent(enrollment: InsertEnrollment): Promise<Enrollment>;
  getStudentsByClass(classId: number): Promise<User[]>;
  
  // Attendance operations
  markAttendance(attendance: InsertAttendanceRecord): Promise<AttendanceRecord>;
  getAttendanceByStudent(studentId: number, limit?: number): Promise<AttendanceRecord[]>;
  getAttendanceByClass(classId: number, date?: Date): Promise<AttendanceRecord[]>;
  getAttendanceStats(studentId: number): Promise<{
    totalClasses: number;
    presentCount: number;
    absentCount: number;
    attendanceRate: number;
  }>;
  
  // Dashboard stats
  getStudentDashboardStats(studentId: number): Promise<{
    attendanceRate: number;
    classesToday: number;
    daysPresent: number;
    daysAbsent: number;
  }>;
  
  getTeacherDashboardStats(teacherId: number): Promise<{
    totalClasses: number;
    totalStudents: number;
    avgAttendance: number;
  }>;
  
  getAdminDashboardStats(): Promise<{
    totalStudents: number;
    totalTeachers: number;
    totalClasses: number;
    avgAttendance: number;
  }>;

  // Admin operations
  getSystemAnalytics(range: string): Promise<{
    attendanceTrends: Array<{
      date: string;
      present: number;
      absent: number;
      late: number;
    }>;
    attendanceByClass: Array<{
      className: string;
      present: number;
      absent: number;
      rate: number;
    }>;
    departmentStats: Array<{
      department: string;
      students: number;
      avgAttendance: number;
    }>;
    overallStats: {
      totalStudents: number;
      totalClasses: number;
      avgAttendanceRate: number;
      totalRecords: number;
    };
  }>;

  getAdvancedReports(from: Date, to: Date, type: string, department: string): Promise<{
    lowAttendanceStudents: Array<{
      id: number;
      name: string;
      email: string;
      department: string;
      attendanceRate: number;
      absences: number;
      classCount: number;
    }>;
    classPerformance: Array<{
      id: number;
      name: string;
      code: string;
      teacherName: string;
      enrollmentCount: number;
      avgAttendance: number;
      trend: "up" | "down" | "stable";
    }>;
    departmentSummary: Array<{
      department: string;
      totalStudents: number;
      avgAttendance: number;
      classCount: number;
      riskStudents: number;
    }>;
    attendanceTrends: Array<{
      date: string;
      totalPresent: number;
      totalAbsent: number;
      rate: number;
    }>;
  }>;

  getDepartments(): Promise<string[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        updatedAt: new Date(),
      })
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({
        ...updates,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id))
      .returning();
    return user || undefined;
  }

  async getClasses(): Promise<Class[]> {
    return await db.select().from(classes).orderBy(asc(classes.name));
  }

  async getClassesByTeacher(teacherId: number): Promise<Class[]> {
    return await db
      .select()
      .from(classes)
      .where(eq(classes.teacherId, teacherId))
      .orderBy(asc(classes.name));
  }

  async getClassesByStudent(studentId: number): Promise<Class[]> {
    return await db
      .select({
        id: classes.id,
        name: classes.name,
        code: classes.code,
        description: classes.description,
        teacherId: classes.teacherId,
        schedule: classes.schedule,
        room: classes.room,
        createdAt: classes.createdAt,
      })
      .from(classes)
      .innerJoin(enrollments, eq(classes.id, enrollments.classId))
      .where(eq(enrollments.studentId, studentId))
      .orderBy(asc(classes.name));
  }

  async createClass(classData: InsertClass): Promise<Class> {
    const [newClass] = await db
      .insert(classes)
      .values(classData)
      .returning();
    return newClass;
  }

  async getClass(id: number): Promise<Class | undefined> {
    const [classData] = await db.select().from(classes).where(eq(classes.id, id));
    return classData || undefined;
  }

  async enrollStudent(enrollment: InsertEnrollment): Promise<Enrollment> {
    const [newEnrollment] = await db
      .insert(enrollments)
      .values(enrollment)
      .returning();
    return newEnrollment;
  }

  async getStudentsByClass(classId: number): Promise<User[]> {
    return await db
      .select({
        id: users.id,
        firstName: users.firstName,
        lastName: users.lastName,
        email: users.email,
        password: users.password,
        role: users.role,
        studentId: users.studentId,
        department: users.department,
        phone: users.phone,
        profileImageUrl: users.profileImageUrl,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
      })
      .from(users)
      .innerJoin(enrollments, eq(users.id, enrollments.studentId))
      .where(eq(enrollments.classId, classId))
      .orderBy(asc(users.firstName), asc(users.lastName));
  }

  async markAttendance(attendance: InsertAttendanceRecord): Promise<AttendanceRecord> {
    const [record] = await db
      .insert(attendanceRecords)
      .values(attendance)
      .returning();
    return record;
  }

  async getAttendanceByStudent(studentId: number, limit?: number): Promise<AttendanceRecord[]> {
    const query = db
      .select()
      .from(attendanceRecords)
      .where(eq(attendanceRecords.studentId, studentId))
      .orderBy(desc(attendanceRecords.date));
    
    if (limit) {
      return await query.limit(limit);
    }
    
    return await query;
  }

  async getAttendanceByClass(classId: number, date?: Date): Promise<AttendanceRecord[]> {
    if (date) {
      const startOfDay = new Date(date);
      startOfDay.setHours(0, 0, 0, 0);
      const endOfDay = new Date(date);
      endOfDay.setHours(23, 59, 59, 999);
      
      return await db
        .select()
        .from(attendanceRecords)
        .where(
          and(
            eq(attendanceRecords.classId, classId),
            sql`${attendanceRecords.date} >= ${startOfDay}`,
            sql`${attendanceRecords.date} <= ${endOfDay}`
          )
        )
        .orderBy(desc(attendanceRecords.date));
    }
    
    return await db
      .select()
      .from(attendanceRecords)
      .where(eq(attendanceRecords.classId, classId))
      .orderBy(desc(attendanceRecords.date));
  }

  async getAttendanceStats(studentId: number): Promise<{
    totalClasses: number;
    presentCount: number;
    absentCount: number;
    attendanceRate: number;
  }> {
    const [totalResult] = await db
      .select({ count: count() })
      .from(attendanceRecords)
      .where(eq(attendanceRecords.studentId, studentId));

    const [presentResult] = await db
      .select({ count: count() })
      .from(attendanceRecords)
      .where(
        and(
          eq(attendanceRecords.studentId, studentId),
          eq(attendanceRecords.status, 'present')
        )
      );

    const totalClasses = totalResult.count;
    const presentCount = presentResult.count;
    const absentCount = totalClasses - presentCount;
    const attendanceRate = totalClasses > 0 ? (presentCount / totalClasses) * 100 : 0;

    return {
      totalClasses,
      presentCount,
      absentCount,
      attendanceRate,
    };
  }

  async getStudentDashboardStats(studentId: number): Promise<{
    attendanceRate: number;
    classesToday: number;
    daysPresent: number;
    daysAbsent: number;
  }> {
    const stats = await this.getAttendanceStats(studentId);
    
    // Get classes for today (this would need actual schedule data)
    const classesForStudent = await this.getClassesByStudent(studentId);
    
    return {
      attendanceRate: stats.attendanceRate,
      classesToday: classesForStudent.length, // Simplified - would need actual schedule logic
      daysPresent: stats.presentCount,
      daysAbsent: stats.absentCount,
    };
  }

  async getTeacherDashboardStats(teacherId: number): Promise<{
    totalClasses: number;
    totalStudents: number;
    avgAttendance: number;
  }> {
    const teacherClasses = await this.getClassesByTeacher(teacherId);
    
    let totalStudents = 0;
    for (const cls of teacherClasses) {
      const students = await this.getStudentsByClass(cls.id);
      totalStudents += students.length;
    }
    
    // Calculate average attendance across all classes
    // This is simplified - would need more complex calculation in practice
    const avgAttendance = 92.5; // Placeholder
    
    return {
      totalClasses: teacherClasses.length,
      totalStudents,
      avgAttendance,
    };
  }

  async getAdminDashboardStats(): Promise<{
    totalStudents: number;
    totalTeachers: number;
    totalClasses: number;
    avgAttendance: number;
  }> {
    const [studentsResult] = await db
      .select({ count: count() })
      .from(users)
      .where(eq(users.role, 'student'));

    const [teachersResult] = await db
      .select({ count: count() })
      .from(users)
      .where(eq(users.role, 'teacher'));

    const [classesResult] = await db
      .select({ count: count() })
      .from(classes);

    // Calculate system-wide average attendance
    const avgAttendance = 92.5; // Placeholder - would need complex calculation

    return {
      totalStudents: studentsResult.count,
      totalTeachers: teachersResult.count,
      totalClasses: classesResult.count,
      avgAttendance,
    };
  }

  async getUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(asc(users.firstName), asc(users.lastName));
  }

  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  async getSystemAnalytics(range: string): Promise<{
    attendanceTrends: Array<{
      date: string;
      present: number;
      absent: number;
      late: number;
    }>;
    attendanceByClass: Array<{
      className: string;
      present: number;
      absent: number;
      rate: number;
    }>;
    departmentStats: Array<{
      department: string;
      students: number;
      avgAttendance: number;
    }>;
    overallStats: {
      totalStudents: number;
      totalClasses: number;
      avgAttendanceRate: number;
      totalRecords: number;
    };
  }> {
    // Calculate date range
    const days = range === '7d' ? 7 : range === '30d' ? 30 : range === '90d' ? 90 : 365;
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - days);

    // Get attendance trends
    const attendanceTrends = await db
      .select({
        date: sql<string>`DATE(${attendanceRecords.date})`,
        present: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 END)`,
        absent: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'absent' THEN 1 END)`,
        late: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'late' THEN 1 END)`
      })
      .from(attendanceRecords)
      .where(sql`${attendanceRecords.date} >= ${startDate}`)
      .groupBy(sql`DATE(${attendanceRecords.date})`)
      .orderBy(sql`DATE(${attendanceRecords.date})`);

    // Get attendance by class
    const attendanceByClass = await db
      .select({
        className: classes.name,
        present: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 END)`,
        absent: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'absent' THEN 1 END)`,
        total: sql<number>`COUNT(*)`
      })
      .from(attendanceRecords)
      .innerJoin(classes, eq(attendanceRecords.classId, classes.id))
      .where(sql`${attendanceRecords.date} >= ${startDate}`)
      .groupBy(classes.id, classes.name);

    const attendanceByClassWithRate = attendanceByClass.map(item => ({
      className: item.className,
      present: item.present,
      absent: item.absent,
      rate: item.total > 0 ? (item.present / item.total) * 100 : 0
    }));

    // Get department stats
    const departmentStats = await db
      .select({
        department: users.department,
        students: sql<number>`COUNT(DISTINCT ${users.id})`,
        totalRecords: sql<number>`COUNT(${attendanceRecords.id})`,
        presentRecords: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 END)`
      })
      .from(users)
      .leftJoin(attendanceRecords, eq(users.id, attendanceRecords.studentId))
      .where(and(
        eq(users.role, 'student'),
        sql`${attendanceRecords.date} >= ${startDate} OR ${attendanceRecords.date} IS NULL`
      ))
      .groupBy(users.department);

    const departmentStatsWithAvg = departmentStats.map(dept => ({
      department: dept.department || 'Unknown',
      students: dept.students,
      avgAttendance: dept.totalRecords > 0 ? (dept.presentRecords / dept.totalRecords) * 100 : 0
    }));

    // Get overall stats
    const [totalStudentsResult] = await db
      .select({ count: count() })
      .from(users)
      .where(eq(users.role, 'student'));

    const [totalClassesResult] = await db
      .select({ count: count() })
      .from(classes);

    const [totalRecordsResult] = await db
      .select({ count: count() })
      .from(attendanceRecords)
      .where(sql`${attendanceRecords.date} >= ${startDate}`);

    const [presentRecordsResult] = await db
      .select({ count: count() })
      .from(attendanceRecords)
      .where(and(
        sql`${attendanceRecords.date} >= ${startDate}`,
        eq(attendanceRecords.status, 'present')
      ));

    const avgAttendanceRate = totalRecordsResult.count > 0 
      ? (presentRecordsResult.count / totalRecordsResult.count) * 100 
      : 0;

    return {
      attendanceTrends,
      attendanceByClass: attendanceByClassWithRate,
      departmentStats: departmentStatsWithAvg,
      overallStats: {
        totalStudents: totalStudentsResult.count,
        totalClasses: totalClassesResult.count,
        avgAttendanceRate,
        totalRecords: totalRecordsResult.count
      }
    };
  }

  async getAdvancedReports(from: Date, to: Date, type: string, department: string): Promise<{
    lowAttendanceStudents: Array<{
      id: number;
      name: string;
      email: string;
      department: string;
      attendanceRate: number;
      absences: number;
      classCount: number;
    }>;
    classPerformance: Array<{
      id: number;
      name: string;
      code: string;
      teacherName: string;
      enrollmentCount: number;
      avgAttendance: number;
      trend: "up" | "down" | "stable";
    }>;
    departmentSummary: Array<{
      department: string;
      totalStudents: number;
      avgAttendance: number;
      classCount: number;
      riskStudents: number;
    }>;
    attendanceTrends: Array<{
      date: string;
      totalPresent: number;
      totalAbsent: number;
      rate: number;
    }>;
  }> {
    // Low attendance students (below 80%)
    const lowAttendanceStudents = await db
      .select({
        id: users.id,
        name: sql<string>`${users.firstName} || ' ' || ${users.lastName}`,
        email: users.email,
        department: users.department,
        totalRecords: sql<number>`COUNT(${attendanceRecords.id})`,
        presentRecords: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 END)`,
        absentRecords: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'absent' THEN 1 END)`
      })
      .from(users)
      .innerJoin(attendanceRecords, eq(users.id, attendanceRecords.studentId))
      .where(and(
        eq(users.role, 'student'),
        sql`${attendanceRecords.date} BETWEEN ${from} AND ${to}`,
        department !== 'all' ? eq(users.department, department) : sql`1=1`
      ))
      .groupBy(users.id, users.firstName, users.lastName, users.email, users.department)
      .having(sql`(COUNT(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 END) * 100.0 / COUNT(*)) < 80`);

    const lowAttendanceData = lowAttendanceStudents.map(student => ({
      id: student.id,
      name: student.name,
      email: student.email,
      department: student.department || 'Unknown',
      attendanceRate: student.totalRecords > 0 ? (student.presentRecords / student.totalRecords) * 100 : 0,
      absences: student.absentRecords,
      classCount: 1 // Simplified - would need enrollment count
    }));

    // Class performance
    const classPerformance = await db
      .select({
        id: classes.id,
        name: classes.name,
        code: classes.code,
        teacherName: sql<string>`${users.firstName} || ' ' || ${users.lastName}`,
        totalRecords: sql<number>`COUNT(${attendanceRecords.id})`,
        presentRecords: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 END)`,
        enrollmentCount: sql<number>`COUNT(DISTINCT ${enrollments.studentId})`
      })
      .from(classes)
      .innerJoin(users, eq(classes.teacherId, users.id))
      .leftJoin(enrollments, eq(classes.id, enrollments.classId))
      .leftJoin(attendanceRecords, eq(classes.id, attendanceRecords.classId))
      .where(sql`${attendanceRecords.date} BETWEEN ${from} AND ${to} OR ${attendanceRecords.date} IS NULL`)
      .groupBy(classes.id, classes.name, classes.code, users.firstName, users.lastName);

    const classPerformanceData = classPerformance.map(cls => ({
      id: cls.id,
      name: cls.name,
      code: cls.code,
      teacherName: cls.teacherName,
      enrollmentCount: cls.enrollmentCount,
      avgAttendance: cls.totalRecords > 0 ? (cls.presentRecords / cls.totalRecords) * 100 : 0,
      trend: "stable" as "up" | "down" | "stable" // Simplified
    }));

    // Department summary
    const departmentSummary = await db
      .select({
        department: users.department,
        totalStudents: sql<number>`COUNT(DISTINCT ${users.id})`,
        totalRecords: sql<number>`COUNT(${attendanceRecords.id})`,
        presentRecords: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 END)`,
        classCount: sql<number>`COUNT(DISTINCT ${classes.id})`
      })
      .from(users)
      .leftJoin(attendanceRecords, eq(users.id, attendanceRecords.studentId))
      .leftJoin(enrollments, eq(users.id, enrollments.studentId))
      .leftJoin(classes, eq(enrollments.classId, classes.id))
      .where(and(
        eq(users.role, 'student'),
        sql`${attendanceRecords.date} BETWEEN ${from} AND ${to} OR ${attendanceRecords.date} IS NULL`
      ))
      .groupBy(users.department);

    const departmentSummaryData = departmentSummary.map(dept => ({
      department: dept.department || 'Unknown',
      totalStudents: dept.totalStudents,
      avgAttendance: dept.totalRecords > 0 ? (dept.presentRecords / dept.totalRecords) * 100 : 0,
      classCount: dept.classCount,
      riskStudents: 0 // Would need calculation based on low attendance
    }));

    // Attendance trends
    const attendanceTrends = await db
      .select({
        date: sql<string>`DATE(${attendanceRecords.date})`,
        totalPresent: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'present' THEN 1 END)`,
        totalAbsent: sql<number>`COUNT(CASE WHEN ${attendanceRecords.status} = 'absent' THEN 1 END)`,
        total: sql<number>`COUNT(*)`
      })
      .from(attendanceRecords)
      .where(sql`${attendanceRecords.date} BETWEEN ${from} AND ${to}`)
      .groupBy(sql`DATE(${attendanceRecords.date})`)
      .orderBy(sql`DATE(${attendanceRecords.date})`);

    const attendanceTrendsData = attendanceTrends.map(trend => ({
      date: trend.date,
      totalPresent: trend.totalPresent,
      totalAbsent: trend.totalAbsent,
      rate: trend.total > 0 ? (trend.totalPresent / trend.total) * 100 : 0
    }));

    return {
      lowAttendanceStudents: lowAttendanceData,
      classPerformance: classPerformanceData,
      departmentSummary: departmentSummaryData,
      attendanceTrends: attendanceTrendsData
    };
  }

  async getDepartments(): Promise<string[]> {
    const departments = await db
      .selectDistinct({ department: users.department })
      .from(users)
      .where(sql`${users.department} IS NOT NULL`);
    
    return departments.map(d => d.department).filter(Boolean) as string[];
  }
}

export const storage = new DatabaseStorage();
