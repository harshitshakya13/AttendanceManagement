import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import type { Request, Response, NextFunction } from "express";
import { loginSchema, registerSchema, insertAttendanceRecordSchema } from "@shared/schema";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

interface AuthRequest extends Request {
  user?: {
    id: number;
    email: string;
    role: string;
  };
}

// Middleware to verify JWT token
const authenticateToken = (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid or expired token' });
    }
    req.user = user;
    next();
  });
};

// Middleware to check user role
const authorizeRole = (roles: string[]) => {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    next();
  };
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post('/api/auth/register', async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);

      // Create user
      const { confirmPassword, ...userData } = validatedData;
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Generate token
      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      // Remove password from response
      const { password, ...userResponse } = user;
      
      res.status(201).json({
        user: userResponse,
        token,
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : 'Registration failed' 
      });
    }
  });

  app.post('/api/auth/login', async (req, res) => {
    try {
      const { email, password, role } = loginSchema.parse(req.body);
      
      // Find user
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      // Check role
      if (user.role !== role) {
        return res.status(401).json({ message: 'Invalid role for this user' });
      }

      // Verify password
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }

      // Generate token
      const token = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        JWT_SECRET,
        { expiresIn: '24h' }
      );

      // Remove password from response
      const { password: _, ...userResponse } = user;
      
      res.json({
        user: userResponse,
        token,
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : 'Login failed' 
      });
    }
  });

  app.get('/api/auth/me', authenticateToken, async (req: AuthRequest, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ message: 'User not authenticated' });
      }

      const user = await storage.getUser(req.user.id);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      const { password, ...userResponse } = user;
      res.json(userResponse);
    } catch (error) {
      console.error('Get user error:', error);
      res.status(500).json({ message: 'Failed to get user data' });
    }
  });

  // Dashboard stats routes
  app.get('/api/dashboard/student/:id', authenticateToken, async (req: AuthRequest, res) => {
    try {
      const studentId = parseInt(req.params.id);
      
      // Check if user can access this data
      if (req.user?.role !== 'admin' && req.user?.id !== studentId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const stats = await storage.getStudentDashboardStats(studentId);
      res.json(stats);
    } catch (error) {
      console.error('Student dashboard error:', error);
      res.status(500).json({ message: 'Failed to get dashboard data' });
    }
  });

  app.get('/api/dashboard/teacher/:id', authenticateToken, authorizeRole(['teacher', 'admin']), async (req: AuthRequest, res) => {
    try {
      const teacherId = parseInt(req.params.id);
      
      // Check if user can access this data
      if (req.user?.role !== 'admin' && req.user?.id !== teacherId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const stats = await storage.getTeacherDashboardStats(teacherId);
      res.json(stats);
    } catch (error) {
      console.error('Teacher dashboard error:', error);
      res.status(500).json({ message: 'Failed to get dashboard data' });
    }
  });

  app.get('/api/dashboard/admin', authenticateToken, authorizeRole(['admin']), async (req: AuthRequest, res) => {
    try {
      const stats = await storage.getAdminDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error('Admin dashboard error:', error);
      res.status(500).json({ message: 'Failed to get dashboard data' });
    }
  });

  // Attendance routes
  app.post('/api/attendance', authenticateToken, authorizeRole(['teacher', 'admin']), async (req: AuthRequest, res) => {
    try {
      const attendanceData = insertAttendanceRecordSchema.parse({
        ...req.body,
        markedBy: req.user!.id,
        date: new Date(req.body.date),
      });

      const record = await storage.markAttendance(attendanceData);
      res.status(201).json(record);
    } catch (error) {
      console.error('Mark attendance error:', error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : 'Failed to mark attendance' 
      });
    }
  });

  app.get('/api/attendance/student/:id', authenticateToken, async (req: AuthRequest, res) => {
    try {
      const studentId = parseInt(req.params.id);
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      // Check if user can access this data
      if (req.user?.role !== 'admin' && req.user?.role !== 'teacher' && req.user?.id !== studentId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const records = await storage.getAttendanceByStudent(studentId, limit);
      res.json(records);
    } catch (error) {
      console.error('Get student attendance error:', error);
      res.status(500).json({ message: 'Failed to get attendance records' });
    }
  });

  app.get('/api/attendance/class/:id', authenticateToken, authorizeRole(['teacher', 'admin']), async (req: AuthRequest, res) => {
    try {
      const classId = parseInt(req.params.id);
      const date = req.query.date ? new Date(req.query.date as string) : undefined;

      const records = await storage.getAttendanceByClass(classId, date);
      res.json(records);
    } catch (error) {
      console.error('Get class attendance error:', error);
      res.status(500).json({ message: 'Failed to get attendance records' });
    }
  });

  app.get('/api/attendance/stats/:studentId', authenticateToken, async (req: AuthRequest, res) => {
    try {
      const studentId = parseInt(req.params.studentId);
      
      // Check if user can access this data
      if (req.user?.role !== 'admin' && req.user?.role !== 'teacher' && req.user?.id !== studentId) {
        return res.status(403).json({ message: 'Access denied' });
      }

      const stats = await storage.getAttendanceStats(studentId);
      res.json(stats);
    } catch (error) {
      console.error('Get attendance stats error:', error);
      res.status(500).json({ message: 'Failed to get attendance statistics' });
    }
  });

  // Classes routes
  app.get('/api/classes', authenticateToken, async (req: AuthRequest, res) => {
    try {
      let classes;
      
      if (req.user?.role === 'student') {
        classes = await storage.getClassesByStudent(req.user.id);
      } else if (req.user?.role === 'teacher') {
        classes = await storage.getClassesByTeacher(req.user.id);
      } else {
        classes = await storage.getClasses();
      }
      
      res.json(classes);
    } catch (error) {
      console.error('Get classes error:', error);
      res.status(500).json({ message: 'Failed to get classes' });
    }
  });

  app.get('/api/classes/:id/students', authenticateToken, authorizeRole(['teacher', 'admin']), async (req: AuthRequest, res) => {
    try {
      const classId = parseInt(req.params.id);
      const students = await storage.getStudentsByClass(classId);
      
      // Remove password from response
      const studentsResponse = students.map(({ password, ...student }) => student);
      
      res.json(studentsResponse);
    } catch (error) {
      console.error('Get class students error:', error);
      res.status(500).json({ message: 'Failed to get class students' });
    }
  });

  // Admin routes
  app.get('/api/admin/users', authenticateToken, authorizeRole(['admin']), async (req: AuthRequest, res) => {
    try {
      const users = await storage.getUsers();
      // Remove passwords from response
      const usersResponse = users.map(({ password, ...user }) => user);
      res.json(usersResponse);
    } catch (error) {
      console.error('Get users error:', error);
      res.status(500).json({ message: 'Failed to get users' });
    }
  });

  app.post('/api/admin/users', authenticateToken, authorizeRole(['admin']), async (req: AuthRequest, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: 'User already exists' });
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(validatedData.password, 10);

      // Create user
      const { confirmPassword, ...userData } = validatedData;
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });

      // Remove password from response
      const { password, ...userResponse } = user;
      
      res.status(201).json(userResponse);
    } catch (error) {
      console.error('Create user error:', error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : 'Failed to create user' 
      });
    }
  });

  app.delete('/api/admin/users/:id', authenticateToken, authorizeRole(['admin']), async (req: AuthRequest, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Prevent admin from deleting themselves
      if (userId === req.user?.id) {
        return res.status(400).json({ message: 'Cannot delete your own account' });
      }
      
      await storage.deleteUser(userId);
      res.json({ message: 'User deleted successfully' });
    } catch (error) {
      console.error('Delete user error:', error);
      res.status(500).json({ message: 'Failed to delete user' });
    }
  });

  app.get('/api/admin/analytics', authenticateToken, authorizeRole(['admin']), async (req: AuthRequest, res) => {
    try {
      const range = (req.query.range as string) || '30d';
      const analytics = await storage.getSystemAnalytics(range);
      res.json(analytics);
    } catch (error) {
      console.error('Get analytics error:', error);
      res.status(500).json({ message: 'Failed to get analytics' });
    }
  });

  app.get('/api/admin/reports', authenticateToken, authorizeRole(['admin']), async (req: AuthRequest, res) => {
    try {
      const { from, to, type = 'overview', department = 'all' } = req.query as {
        from: string;
        to: string;
        type: string;
        department: string;
      };
      
      const reports = await storage.getAdvancedReports(
        new Date(from),
        new Date(to),
        type,
        department
      );
      res.json(reports);
    } catch (error) {
      console.error('Get reports error:', error);
      res.status(500).json({ message: 'Failed to get reports' });
    }
  });

  app.get('/api/admin/departments', authenticateToken, authorizeRole(['admin']), async (req: AuthRequest, res) => {
    try {
      const departments = await storage.getDepartments();
      res.json(departments);
    } catch (error) {
      console.error('Get departments error:', error);
      res.status(500).json({ message: 'Failed to get departments' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
