import bcrypt from "bcrypt";
import { db } from "./db";
import { users, classes, enrollments, attendanceRecords } from "@shared/schema";

async function seed() {
  try {
    console.log("Starting database seeding...");

    // Create sample users
    const hashedPassword = await bcrypt.hash("password123", 10);

    // Create admin user
    const [admin] = await db.insert(users).values({
      firstName: "Admin",
      lastName: "User",
      email: "admin@attendancehub.com",
      password: hashedPassword,
      role: "admin",
      department: "Administration",
    }).returning();

    // Create teacher users
    const [teacher1] = await db.insert(users).values({
      firstName: "John",
      lastName: "Smith",
      email: "john.smith@attendancehub.com",
      password: hashedPassword,
      role: "teacher",
      department: "Mathematics",
    }).returning();

    const [teacher2] = await db.insert(users).values({
      firstName: "Sarah",
      lastName: "Johnson",
      email: "sarah.johnson@attendancehub.com",
      password: hashedPassword,
      role: "teacher",
      department: "Computer Science",
    }).returning();

    // Create student users
    const [student1] = await db.insert(users).values({
      firstName: "Alice",
      lastName: "Wilson",
      email: "alice.wilson@student.edu",
      password: hashedPassword,
      role: "student",
      studentId: "STU001",
      department: "Computer Science",
    }).returning();

    const [student2] = await db.insert(users).values({
      firstName: "Bob",
      lastName: "Davis",
      email: "bob.davis@student.edu",
      password: hashedPassword,
      role: "student",
      studentId: "STU002",
      department: "Mathematics",
    }).returning();

    const [student3] = await db.insert(users).values({
      firstName: "Emma",
      lastName: "Brown",
      email: "emma.brown@student.edu",
      password: hashedPassword,
      role: "student",
      studentId: "STU003",
      department: "Computer Science",
    }).returning();

    // Create classes
    const [mathClass] = await db.insert(classes).values({
      name: "Calculus I",
      code: "MATH101",
      description: "Introduction to differential and integral calculus",
      teacherId: teacher1.id,
      room: "Room 101",
      schedule: JSON.stringify({
        days: ["Monday", "Wednesday", "Friday"],
        time: "09:00-10:30"
      }),
    }).returning();

    const [csClass] = await db.insert(classes).values({
      name: "Data Structures",
      code: "CS201",
      description: "Fundamental data structures and algorithms",
      teacherId: teacher2.id,
      room: "Lab 201",
      schedule: JSON.stringify({
        days: ["Tuesday", "Thursday"],
        time: "14:00-15:30"
      }),
    }).returning();

    const [algorithmClass] = await db.insert(classes).values({
      name: "Algorithm Design",
      code: "CS301",
      description: "Advanced algorithm design and analysis",
      teacherId: teacher2.id,
      room: "Lab 202",
      schedule: JSON.stringify({
        days: ["Monday", "Wednesday"],
        time: "11:00-12:30"
      }),
    }).returning();

    // Create enrollments
    await db.insert(enrollments).values([
      { studentId: student1.id, classId: csClass.id },
      { studentId: student1.id, classId: algorithmClass.id },
      { studentId: student2.id, classId: mathClass.id },
      { studentId: student2.id, classId: csClass.id },
      { studentId: student3.id, classId: csClass.id },
      { studentId: student3.id, classId: algorithmClass.id },
    ]);

    // Create sample attendance records (last 30 days)
    const dates = [];
    for (let i = 29; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      dates.push(date);
    }

    const attendanceData = [];
    
    // Generate attendance for each student in their enrolled classes
    for (const date of dates) {
      // Skip weekends for simplicity
      if (date.getDay() === 0 || date.getDay() === 6) continue;

      // Student 1 - CS classes (high attendance)
      if (Math.random() > 0.05) { // 95% attendance
        attendanceData.push({
          studentId: student1.id,
          classId: csClass.id,
          date,
          status: "present",
          markedBy: teacher2.id,
        });
      } else {
        attendanceData.push({
          studentId: student1.id,
          classId: csClass.id,
          date,
          status: "absent",
          markedBy: teacher2.id,
        });
      }

      if (Math.random() > 0.1) { // 90% attendance
        attendanceData.push({
          studentId: student1.id,
          classId: algorithmClass.id,
          date,
          status: "present",
          markedBy: teacher2.id,
        });
      } else {
        attendanceData.push({
          studentId: student1.id,
          classId: algorithmClass.id,
          date,
          status: "absent",
          markedBy: teacher2.id,
        });
      }

      // Student 2 - Math and CS (medium attendance)
      if (Math.random() > 0.15) { // 85% attendance
        attendanceData.push({
          studentId: student2.id,
          classId: mathClass.id,
          date,
          status: "present",
          markedBy: teacher1.id,
        });
      } else {
        attendanceData.push({
          studentId: student2.id,
          classId: mathClass.id,
          date,
          status: "absent",
          markedBy: teacher1.id,
        });
      }

      if (Math.random() > 0.2) { // 80% attendance
        attendanceData.push({
          studentId: student2.id,
          classId: csClass.id,
          date,
          status: "present",
          markedBy: teacher2.id,
        });
      } else {
        attendanceData.push({
          studentId: student2.id,
          classId: csClass.id,
          date,
          status: "absent",
          markedBy: teacher2.id,
        });
      }

      // Student 3 - CS classes (good attendance)
      if (Math.random() > 0.12) { // 88% attendance
        attendanceData.push({
          studentId: student3.id,
          classId: csClass.id,
          date,
          status: "present",
          markedBy: teacher2.id,
        });
      } else {
        attendanceData.push({
          studentId: student3.id,
          classId: csClass.id,
          date,
          status: "absent",
          markedBy: teacher2.id,
        });
      }

      if (Math.random() > 0.08) { // 92% attendance
        attendanceData.push({
          studentId: student3.id,
          classId: algorithmClass.id,
          date,
          status: "present",
          markedBy: teacher2.id,
        });
      } else {
        attendanceData.push({
          studentId: student3.id,
          classId: algorithmClass.id,
          date,
          status: "absent",
          markedBy: teacher2.id,
        });
      }
    }

    if (attendanceData.length > 0) {
      await db.insert(attendanceRecords).values(attendanceData);
    }

    console.log("✅ Database seeded successfully!");
    console.log("Sample accounts created:");
    console.log("Admin: admin@attendancehub.com / password123");
    console.log("Teacher: john.smith@attendancehub.com / password123");
    console.log("Teacher: sarah.johnson@attendancehub.com / password123");
    console.log("Student: alice.wilson@student.edu / password123");
    console.log("Student: bob.davis@student.edu / password123");
    console.log("Student: emma.brown@student.edu / password123");

  } catch (error) {
    console.error("❌ Error seeding database:", error);
  }
}

// Run seeding
seed();