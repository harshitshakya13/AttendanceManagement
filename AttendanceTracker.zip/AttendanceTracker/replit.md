# replit.md

## Overview

This is a full-stack attendance management system built with Express.js, React, and PostgreSQL. The application serves students, teachers, and administrators with role-based access control and comprehensive attendance tracking features.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a monorepo structure with a clear separation between client and server code:

- **Frontend**: React application with TypeScript, using Vite as the build tool
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Authentication**: JWT-based authentication with bcrypt password hashing
- **UI Framework**: shadcn/ui components built on Radix UI primitives with Tailwind CSS

## Key Components

### Frontend Structure
- **Client Application**: Located in `/client` directory
- **React Router**: Uses Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: shadcn/ui component library with dark/light theme support
- **Authentication**: Custom auth hooks with JWT token management

### Backend Structure
- **Server**: Express.js application in `/server` directory
- **Database Layer**: Drizzle ORM with Neon serverless PostgreSQL
- **API Routes**: RESTful endpoints for authentication, classes, and attendance
- **Middleware**: JWT authentication and role-based authorization

### Database Schema
The system uses four main tables:
- **users**: Stores user information with role-based access (student, teacher, admin)
- **classes**: Course/class information with teacher assignments
- **enrollments**: Many-to-many relationship between students and classes
- **attendanceRecords**: Tracks attendance status with timestamps

## Data Flow

1. **Authentication Flow**:
   - Users login through the landing page modal
   - JWT tokens are stored in localStorage
   - Protected routes verify tokens server-side
   - Role-based access controls restrict functionality

2. **Attendance Management**:
   - Teachers mark attendance for their classes
   - Students view their attendance records and statistics
   - Admins have system-wide visibility and management capabilities

3. **Dashboard System**:
   - Role-specific dashboards (student, teacher, admin)
   - Real-time statistics and recent activity displays
   - Responsive design for mobile and desktop usage

## External Dependencies

### Core Technologies
- **@neondatabase/serverless**: Serverless PostgreSQL database connection
- **drizzle-orm**: Type-safe ORM for database operations
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight React router
- **jsonwebtoken**: JWT authentication implementation
- **bcrypt**: Password hashing and verification

### UI Libraries
- **@radix-ui**: Accessible component primitives
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Component variant management
- **lucide-react**: Icon library

### Development Tools
- **vite**: Frontend build tool with HMR support
- **typescript**: Type safety across the entire application
- **drizzle-kit**: Database migration and schema management

## Deployment Strategy

### Development Environment
- **Vite Dev Server**: Frontend development with hot module replacement
- **Express Server**: Backend API server with TypeScript compilation
- **Database**: Neon serverless PostgreSQL with connection pooling

### Production Build
- **Frontend**: Vite builds static assets to `dist/public`
- **Backend**: esbuild compiles TypeScript server code to `dist`
- **Database Migrations**: Drizzle Kit handles schema changes via `db:push` command

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **JWT_SECRET**: Secret key for JWT token signing
- **NODE_ENV**: Environment specification (development/production)

The application is designed to be deployed on platforms like Replit, with proper environment variable configuration for database connectivity and security.

## Recent Changes

### January 2025 - Enhanced Theme Design and Animation System
- **Modern Theme Overhaul**: Updated color scheme with purple primary colors and enhanced gradients
- **Advanced Animation System**: Added comprehensive CSS animations including:
  - Fade-in, slide-up, scale-in, and bounce-in animations
  - Floating elements with continuous motion
  - Pulse-glow effects for interactive elements
  - Card hover effects with smooth transitions
- **Loading States Implementation**: Created comprehensive loading system:
  - Custom loading spinners and skeleton components
  - Action loaders for button states and form submissions
  - Loading overlays for dashboard sections
  - Smooth skeleton animations for better UX
- **Dashboard Enhancements**: Applied modern animations and loading states to all dashboards:
  - Student dashboard with animated stat cards and gradient quick actions
  - Teacher dashboard with enhanced attendance marking interface
  - Admin dashboard with animated system overview cards
- **Gradient Backgrounds**: Added subtle gradient backgrounds throughout the application
- **Performance Optimizations**: Staggered animation delays for better visual flow

### January 2025 - Complete UI Overhaul and Database Setup
- **Landing Page Enhancement**: Added comprehensive footer with branding, links, social media, and contact information
- **Contact Section**: Added attractive contact section with gradient background, contact info, and call-to-action
- **Database Seeding**: Implemented complete database seeding with sample users, classes, enrollments, and 30 days of attendance data
- **Sample Accounts Created**:
  - Admin: admin@attendancehub.com / password123
  - Teachers: john.smith@attendancehub.com, sarah.johnson@attendancehub.com / password123  
  - Students: alice.wilson@student.edu, bob.davis@student.edu, emma.brown@student.edu / password123
- **Bug Fixes**: Resolved Drizzle ORM query builder issues in storage layer
- **UI Polish**: Enhanced landing page with modern gradients, better spacing, and professional footer design