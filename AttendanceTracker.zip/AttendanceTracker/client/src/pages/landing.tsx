import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Navigation } from "@/components/layout/navigation";
import { Footer } from "@/components/layout/footer";
import { AuthModal } from "@/components/auth/auth-modal";
import { CheckCircle, Users, GraduationCap, Shield, Mail, Phone, MapPin, MessageCircle } from "lucide-react";

export default function Landing() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const features = [
    {
      title: "For Students",
      icon: GraduationCap,
      color: "bg-blue-500",
      items: [
        "View attendance records",
        "Check class schedules",
        "Generate reports",
        "Profile management",
      ],
    },
    {
      title: "For Teachers",
      icon: Users,
      color: "bg-green-500",
      items: [
        "Mark attendance",
        "Manage classes",
        "View student records",
        "Generate class reports",
      ],
    },
    {
      title: "For Admins",
      icon: Shield,
      color: "bg-purple-500",
      items: [
        "User management",
        "System analytics",
        "Role assignments",
        "Advanced reporting",
      ],
    },
  ];

  const stats = [
    { value: "10k+", label: "Students", color: "text-primary" },
    { value: "500+", label: "Teachers", color: "text-green-500" },
    { value: "100+", label: "Schools", color: "text-yellow-500" },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
      <Navigation onLoginClick={() => setIsAuthModalOpen(true)} />

      {/* Hero Section */}
      <section className="relative py-20 lg:py-32">
        {/* Background Pattern */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-10 left-10 w-32 h-32 bg-primary/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-40 h-40 bg-green-500/10 rounded-full blur-3xl"></div>
          <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-yellow-500/10 rounded-full blur-2xl"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 dark:text-white leading-tight">
                  Smart <span className="text-primary">Attendance</span> Management
                </h1>
                <p className="text-xl text-gray-600 dark:text-gray-300 leading-relaxed">
                  Streamline your institution's attendance tracking with our modern,
                  role-based management system. Designed for students, teachers, and
                  administrators.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  size="lg"
                  onClick={() => setIsAuthModalOpen(true)}
                  className="px-8 py-6 text-lg font-semibold"
                >
                  Get Started
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="px-8 py-6 text-lg font-semibold"
                >
                  Learn More
                </Button>
              </div>

              <div className="flex items-center space-x-8 pt-4">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center">
                    <div className={`text-2xl font-bold ${stat.color}`}>
                      {stat.value}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <Card className="shadow-2xl">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Dashboard Preview
                    </h3>
                    <div className="flex space-x-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-primary/10 p-4 rounded-xl">
                        <div className="text-primary text-2xl font-bold">95%</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          Attendance Rate
                        </div>
                      </div>
                      <div className="bg-green-500/10 p-4 rounded-xl">
                        <div className="text-green-500 text-2xl font-bold">24</div>
                        <div className="text-sm text-gray-600 dark:text-gray-400">
                          Days Present
                        </div>
                      </div>
                    </div>
                    <div className="h-32 bg-gray-100 dark:bg-slate-700 rounded-xl flex items-center justify-center">
                      <div className="text-gray-500 dark:text-gray-400">
                        📊 Interactive Chart
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white dark:bg-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Powerful Features for Every Role
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Our comprehensive attendance management system provides tailored
              experiences for students, teachers, and administrators.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="hover:shadow-lg transition-shadow duration-300">
                  <CardContent className="p-8">
                    <div className={`${feature.color} w-12 h-12 rounded-xl flex items-center justify-center mb-6`}>
                      <Icon className="text-white h-6 w-6" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                      {feature.title}
                    </h3>
                    <ul className="space-y-3 text-gray-600 dark:text-gray-300">
                      {feature.items.map((item, itemIndex) => (
                        <li key={itemIndex} className="flex items-center">
                          <CheckCircle className="text-green-500 h-4 w-4 mr-3 flex-shrink-0" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gradient-to-r from-primary to-green-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-white mb-4">
              Get Started Today
            </h2>
            <p className="text-xl text-blue-100 max-w-2xl mx-auto">
              Ready to transform your attendance management? Contact us or start your free trial now.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Contact Info */}
            <div className="space-y-6">
              <div className="flex items-center space-x-4 text-white">
                <div className="bg-white/20 p-3 rounded-lg">
                  <Mail className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold">Email Us</h3>
                  <p className="text-blue-100">contact@attendancehub.com</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 text-white">
                <div className="bg-white/20 p-3 rounded-lg">
                  <Phone className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold">Call Us</h3>
                  <p className="text-blue-100">+1 (555) 123-4567</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 text-white">
                <div className="bg-white/20 p-3 rounded-lg">
                  <MapPin className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold">Visit Us</h3>
                  <p className="text-blue-100">San Francisco, CA</p>
                </div>
              </div>

              <div className="flex items-center space-x-4 text-white">
                <div className="bg-white/20 p-3 rounded-lg">
                  <MessageCircle className="h-6 w-6" />
                </div>
                <div>
                  <h3 className="font-semibold">Live Chat</h3>
                  <p className="text-blue-100">Available 24/7 for support</p>
                </div>
              </div>
            </div>

            {/* CTA Card */}
            <Card className="shadow-2xl">
              <CardContent className="p-8">
                <div className="text-center space-y-6">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                    Start Your Free Trial
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300">
                    Join thousands of institutions already using AttendanceHub to streamline their attendance management.
                  </p>
                  <div className="space-y-4">
                    <Button
                      onClick={() => setIsAuthModalOpen(true)}
                      size="lg"
                      className="w-full text-lg font-semibold py-6"
                    >
                      Get Started Free
                    </Button>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      No credit card required • Free 30-day trial
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />
    </div>
  );
}
