import { Button } from "@/components/ui/button";
import { Navigation } from "@/components/layout/navigation";
import { useAuth } from "@/hooks/useAuth";
import { ShieldX, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function AccessDenied() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const handleGoBack = () => {
    if (user) {
      // Redirect to appropriate dashboard based on user role
      setLocation(`/dashboard/${user.role}`);
    } else {
      setLocation("/");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="flex items-center justify-center min-h-[80vh]">
        <div className="text-center p-8 max-w-md mx-4">
          <div className="bg-red-100 dark:bg-red-900/20 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
            <ShieldX className="text-red-500 h-12 w-12" />
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Access Denied
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
            You don't have permission to access this resource. Please contact your
            administrator if you believe this is an error.
          </p>
          
          <Button onClick={handleGoBack} className="inline-flex items-center">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Go Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
}
