import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Navigation } from "@/components/layout/navigation";
import { LoadingOverlay, SkeletonCard, LoadingSpinner } from "@/components/ui/loading";
import { useAuth } from "@/hooks/useAuth";
import { authService } from "@/lib/auth";
import { CalendarCheck, Book, Calendar, CalendarX, Clock } from "lucide-react";

export default function StudentDashboard() {
  const { user } = useAuth();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: [`/api/dashboard/student/${user?.id}`],
    enabled: !!user?.id,
    queryFn: async () => {
      const res = await fetch(`/api/dashboard/student/${user?.id}`, {
        headers: authService.getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed to fetch dashboard stats");
      return res.json();
    },
  });

  const { data: recentAttendance } = useQuery({
    queryKey: [`/api/attendance/student/${user?.id}?limit=5`],
    enabled: !!user?.id,
    queryFn: async () => {
      const res = await fetch(`/api/attendance/student/${user?.id}?limit=5`, {
        headers: authService.getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed to fetch attendance records");
      return res.json();
    },
  });

  const { data: classes } = useQuery({
    queryKey: ["/api/classes"],
    enabled: !!user?.id,
    queryFn: async () => {
      const res = await fetch("/api/classes", {
        headers: authService.getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed to fetch classes");
      return res.json();
    },
  });

  if (statsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8 animate-fade-in">
            <div className="skeleton-title" />
            <div className="skeleton-text w-1/2" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <SkeletonCard />
            <SkeletonCard />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </div>
        </div>
      </div>
    );
  }

  const statCards = [
    {
      title: "Attendance Rate",
      value: `${stats?.attendanceRate?.toFixed(1) || 0}%`,
      icon: CalendarCheck,
      color: "text-green-500",
      bgColor: "bg-green-100 dark:bg-green-900/20",
    },
    {
      title: "Classes Today",
      value: stats?.classesToday || 0,
      icon: Book,
      color: "text-blue-500",
      bgColor: "bg-blue-100 dark:bg-blue-900/20",
    },
    {
      title: "Days Present",
      value: stats?.daysPresent || 0,
      icon: Calendar,
      color: "text-purple-500",
      bgColor: "bg-purple-100 dark:bg-purple-900/20",
    },
    {
      title: "Days Absent",
      value: stats?.daysAbsent || 0,
      icon: CalendarX,
      color: "text-red-500",
      bgColor: "bg-red-100 dark:bg-red-900/20",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Student Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Welcome back, {user?.firstName}! Here's your attendance overview.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="card-hover border-primary/20 hover:border-primary/40 transition-all duration-300 cursor-pointer animate-scale-in bg-gradient-primary text-white" onClick={() => window.location.href = '/student/attendance'}>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="bg-white/20 p-3 rounded-xl animate-float">
                  <CalendarCheck className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold text-white">View Attendance Records</h3>
                  <p className="text-sm text-white/80">Check your attendance history and statistics</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="card-hover border-primary/20 hover:border-primary/40 transition-all duration-300 cursor-pointer animate-scale-in bg-gradient-secondary" onClick={() => window.location.href = '/student/schedule'} style={{ animationDelay: '0.1s' }}>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="bg-primary/10 p-3 rounded-xl animate-float" style={{ animationDelay: '0.5s' }}>
                  <Calendar className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white">View Class Schedule</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">See your weekly class timetable</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statCards.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="card-hover animate-bounce-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {stat.title}
                      </p>
                      <p className={`text-3xl font-bold ${stat.color} animate-pulse-glow`}>
                        {stat.value}
                      </p>
                    </div>
                    <div className={`${stat.bgColor} p-4 rounded-xl animate-float`} style={{ animationDelay: `${index * 0.2}s` }}>
                      <Icon className={`${stat.color} h-7 w-7`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Recent Attendance and Schedule */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Attendance */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Attendance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentAttendance && recentAttendance.length > 0 ? (
                  recentAttendance.map((record: any, index: number) => (
                    <div
                      key={index}
                      className={`flex items-center justify-between p-3 rounded-lg ${
                        record.status === "present"
                          ? "bg-green-50 dark:bg-green-900/20"
                          : "bg-red-50 dark:bg-red-900/20"
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-2 h-2 rounded-full ${
                            record.status === "present" ? "bg-green-500" : "bg-red-500"
                          }`}
                        ></div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">
                            Class {record.classId}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {new Date(record.date).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <span
                        className={`font-medium capitalize ${
                          record.status === "present" ? "text-green-500" : "text-red-500"
                        }`}
                      >
                        {record.status}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    No attendance records found
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Today's Schedule */}
          <Card>
            <CardHeader>
              <CardTitle>Your Classes</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {classes && classes.length > 0 ? (
                  classes.map((cls: any, index: number) => (
                    <div
                      key={index}
                      className="flex items-center space-x-4 p-3 border border-gray-200 dark:border-slate-600 rounded-lg"
                    >
                      <div className="text-center">
                        <Clock className="h-5 w-5 text-gray-500 dark:text-gray-400 mx-auto" />
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900 dark:text-white">
                          {cls.name}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {cls.code} • {cls.room || "Room TBD"}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    No classes enrolled
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
