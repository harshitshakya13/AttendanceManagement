import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Navigation } from "@/components/layout/navigation";
import { useAuth } from "@/hooks/useAuth";
import { Calendar, Clock, MapPin, User, BookOpen, ChevronLeft, ChevronRight } from "lucide-react";
import { format, addDays, startOfWeek, isSameDay } from "date-fns";

export default function StudentSchedule() {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [currentWeek, setCurrentWeek] = useState(startOfWeek(new Date()));

  const { data: schedule, isLoading } = useQuery({
    queryKey: ['/api/classes', user?.id],
    enabled: !!user?.id,
  });

  const weekDays = Array.from({ length: 7 }, (_, i) => addDays(currentWeek, i));

  const getTodayClasses = () => {
    if (!schedule) return [];
    return schedule.filter((cls: any) => {
      // For demo purposes, showing all classes with time slots
      return true;
    });
  };

  const getClassesForDate = (date: Date) => {
    if (!schedule) return [];
    // Filter classes that occur on this day of the week
    const dayOfWeek = date.getDay();
    return schedule.filter((cls: any) => {
      // Demo: assign different classes to different days
      const classDays = {
        0: [], // Sunday
        1: [0, 1], // Monday - first 2 classes
        2: [1, 2], // Tuesday
        3: [0, 2], // Wednesday
        4: [1], // Thursday
        5: [0], // Friday
        6: [], // Saturday
      };
      return classDays[dayOfWeek as keyof typeof classDays]?.includes(cls.id % 3);
    });
  };

  const navigateWeek = (direction: 'prev' | 'next') => {
    setCurrentWeek(addDays(currentWeek, direction === 'next' ? 7 : -7));
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Class Schedule
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            View your weekly class schedule and upcoming sessions
          </p>
        </div>

        {/* Today's Classes Quick View */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Today's Classes - {format(new Date(), 'EEEE, MMMM dd')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {getTodayClasses().slice(0, 3).map((cls: any, index) => (
                <Card key={cls.id} className="border-l-4 border-l-primary">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-semibold text-gray-900 dark:text-white">
                        {cls.name}
                      </h3>
                      <Badge variant="secondary">{cls.code}</Badge>
                    </div>
                    <div className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-2" />
                        {9 + index}:00 AM - {10 + index}:30 AM
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        Room {100 + cls.id}
                      </div>
                      <div className="flex items-center">
                        <User className="h-4 w-4 mr-2" />
                        {cls.teacherName || 'TBA'}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {getTodayClasses().length === 0 && (
                <div className="col-span-full text-center py-8 text-gray-500">
                  No classes scheduled for today
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Weekly Schedule */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center">
                <BookOpen className="h-5 w-5 mr-2" />
                Weekly Schedule
              </CardTitle>
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="sm" onClick={() => navigateWeek('prev')}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm font-medium px-4">
                  {format(currentWeek, 'MMM dd')} - {format(addDays(currentWeek, 6), 'MMM dd, yyyy')}
                </span>
                <Button variant="outline" size="sm" onClick={() => navigateWeek('next')}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-gray-500">
                Loading schedule...
              </div>
            ) : (
              <div className="grid grid-cols-7 gap-4">
                {weekDays.map((day, index) => {
                  const dayClasses = getClassesForDate(day);
                  const isToday = isSameDay(day, new Date());
                  
                  return (
                    <div
                      key={index}
                      className={`border rounded-lg p-4 ${
                        isToday 
                          ? 'bg-primary/10 border-primary' 
                          : 'bg-white dark:bg-slate-800 border-gray-200 dark:border-gray-700'
                      }`}
                    >
                      <div className="text-center mb-4">
                        <h3 className={`font-semibold ${
                          isToday ? 'text-primary' : 'text-gray-900 dark:text-white'
                        }`}>
                          {format(day, 'EEE')}
                        </h3>
                        <p className={`text-sm ${
                          isToday ? 'text-primary' : 'text-gray-600 dark:text-gray-400'
                        }`}>
                          {format(day, 'MMM dd')}
                        </p>
                      </div>
                      
                      <div className="space-y-2">
                        {dayClasses.map((cls: any, clsIndex) => (
                          <div
                            key={`${cls.id}-${clsIndex}`}
                            className="bg-gray-50 dark:bg-slate-700 rounded p-2 text-xs"
                          >
                            <div className="font-medium text-gray-900 dark:text-white mb-1">
                              {cls.name}
                            </div>
                            <div className="text-gray-600 dark:text-gray-400">
                              {9 + (clsIndex * 2)}:00 AM
                            </div>
                            <div className="text-gray-600 dark:text-gray-400">
                              Room {100 + cls.id}
                            </div>
                          </div>
                        ))}
                        {dayClasses.length === 0 && (
                          <div className="text-center py-4 text-gray-400 text-xs">
                            No classes
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Upcoming Classes */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Upcoming Classes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {schedule?.slice(0, 5).map((cls: any, index) => (
                <div
                  key={cls.id}
                  className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg"
                >
                  <div className="flex items-center space-x-4">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      <BookOpen className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900 dark:text-white">
                        {cls.name}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {cls.code} • Room {100 + cls.id}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {format(addDays(new Date(), index), 'MMM dd')}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {9 + index}:00 AM
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}