import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Navigation } from "@/components/layout/navigation";
import { LoadingOverlay, SkeletonCard, LoadingSpinner } from "@/components/ui/loading";
import { useAuth } from "@/hooks/useAuth";
import { authService } from "@/lib/auth";
import { UserPlus, Settings, Users, Eye, BarChart3, Download } from "lucide-react";

export default function AdminDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/admin"],
    enabled: !!user?.id,
    queryFn: async () => {
      const res = await fetch("/api/dashboard/admin", {
        headers: authService.getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed to fetch dashboard stats");
      return res.json();
    },
  });

  if (statsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8 animate-fade-in">
            <div className="skeleton-title" />
            <div className="skeleton-text w-1/2" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </div>
        </div>
      </div>
    );
  }

  const systemStats = [
    {
      title: "Total Students",
      value: stats?.totalStudents || 0,
      icon: Users,
      color: "text-blue-500",
      bgColor: "bg-blue-100 dark:bg-blue-900/20",
    },
    {
      title: "Total Teachers",
      value: stats?.totalTeachers || 0,
      icon: Users,
      color: "text-green-500",
      bgColor: "bg-green-100 dark:bg-green-900/20",
    },
    {
      title: "Active Classes",
      value: stats?.totalClasses || 0,
      icon: Users,
      color: "text-purple-500",
      bgColor: "bg-purple-100 dark:bg-purple-900/20",
    },
    {
      title: "Avg. Attendance",
      value: `${stats?.avgAttendance?.toFixed(1) || 0}%`,
      icon: BarChart3,
      color: "text-yellow-500",
      bgColor: "bg-yellow-100 dark:bg-yellow-900/20",
    },
  ];

  const userManagementActions = [
    {
      title: "Add New User",
      description: "Create student, teacher, or admin accounts",
      icon: UserPlus,
      color: "text-blue-500",
      onClick: () => setLocation("/admin/users"),
    },
    {
      title: "Manage Roles",
      description: "Assign and modify user permissions",
      icon: Settings,
      color: "text-green-500",
      onClick: () => setLocation("/admin/users"),
    },
    {
      title: "View All Users",
      description: "Browse and search user directory",
      icon: Eye,
      color: "text-purple-500",
      onClick: () => setLocation("/admin/users"),
    },
  ];

  const systemReportActions = [
    {
      title: "Attendance Analytics",
      description: "Comprehensive attendance statistics",
      icon: BarChart3,
      color: "text-blue-500",
      onClick: () => setLocation("/admin/analytics"),
    },
    {
      title: "Advanced Reports",
      description: "Generate detailed system reports",
      icon: Download,
      color: "text-green-500",
      onClick: () => setLocation("/admin/reports"),
    },
    {
      title: "System Settings",
      description: "Configure system preferences",
      icon: Settings,
      color: "text-purple-500",
      onClick: () => setLocation("/admin/analytics"),
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Admin Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            System Administrator - Manage users, classes, and system settings.
          </p>
        </div>

        {/* System Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {systemStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card key={index} className="card-hover animate-bounce-in" style={{ animationDelay: `${index * 0.1}s` }}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {stat.title}
                      </p>
                      <p className={`text-3xl font-bold ${stat.color} animate-pulse-glow`}>
                        {stat.value}
                      </p>
                    </div>
                    <div className={`${stat.bgColor} p-4 rounded-xl animate-float`} style={{ animationDelay: `${index * 0.2}s` }}>
                      <Icon className={`${stat.color} h-7 w-7`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Admin Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* User Management */}
          <Card className="card-hover animate-slide-up">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5 text-primary" />
                User Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {userManagementActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Button
                    key={index}
                    variant="ghost"
                    className="w-full justify-start h-auto p-4"
                    onClick={action.onClick}
                  >
                    <div className="flex items-center space-x-3">
                      <Icon className={`${action.color} h-5 w-5`} />
                      <div className="text-left">
                        <p className="font-medium text-gray-900 dark:text-white">
                          {action.title}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {action.description}
                        </p>
                      </div>
                    </div>
                  </Button>
                );
              })}
            </CardContent>
          </Card>

          {/* System Reports */}
          <Card>
            <CardHeader>
              <CardTitle>System Reports</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {systemReportActions.map((action, index) => {
                const Icon = action.icon;
                return (
                  <Button
                    key={index}
                    variant="ghost"
                    className="w-full justify-start h-auto p-4"
                    onClick={action.onClick}
                  >
                    <div className="flex items-center space-x-3">
                      <Icon className={`${action.color} h-5 w-5`} />
                      <div className="text-left">
                        <p className="font-medium text-gray-900 dark:text-white">
                          {action.title}
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-400">
                          {action.description}
                        </p>
                      </div>
                    </div>
                  </Button>
                );
              })}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
