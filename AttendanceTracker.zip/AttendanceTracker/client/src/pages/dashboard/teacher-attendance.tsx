import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Navigation } from "@/components/layout/navigation";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CheckCircle, XCircle, Clock, Users, Save, Calendar } from "lucide-react";
import { format } from "date-fns";

interface AttendanceRecord {
  studentId: number;
  studentName: string;
  status: 'present' | 'absent' | 'late';
}

export default function TeacherAttendance() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedClass, setSelectedClass] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);

  const { data: teacherClasses, isLoading: classesLoading } = useQuery({
    queryKey: ['/api/teacher/classes', user?.id],
    enabled: !!user?.id,
  });

  const { data: classStudents, isLoading: studentsLoading } = useQuery({
    queryKey: ['/api/classes', selectedClass, 'students'],
    enabled: !!selectedClass,
    onSuccess: (students) => {
      // Initialize attendance records for all students
      setAttendanceRecords(
        students.map((student: any) => ({
          studentId: student.id,
          studentName: `${student.firstName} ${student.lastName}`,
          status: 'present' as const,
        }))
      );
    },
  });

  const saveAttendanceMutation = useMutation({
    mutationFn: async (data: { classId: string; date: string; records: AttendanceRecord[] }) => {
      const response = await apiRequest('POST', '/api/attendance/mark', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Attendance Saved",
        description: "Attendance has been successfully recorded for all students.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/attendance'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save attendance",
        variant: "destructive",
      });
    },
  });

  const updateAttendanceStatus = (studentId: number, status: 'present' | 'absent' | 'late') => {
    setAttendanceRecords(prev =>
      prev.map(record =>
        record.studentId === studentId ? { ...record, status } : record
      )
    );
  };

  const markAllPresent = () => {
    setAttendanceRecords(prev =>
      prev.map(record => ({ ...record, status: 'present' as const }))
    );
  };

  const markAllAbsent = () => {
    setAttendanceRecords(prev =>
      prev.map(record => ({ ...record, status: 'absent' as const }))
    );
  };

  const handleSaveAttendance = () => {
    if (!selectedClass || !selectedDate) {
      toast({
        title: "Missing Information",
        description: "Please select a class and date before saving attendance.",
        variant: "destructive",
      });
      return;
    }

    saveAttendanceMutation.mutate({
      classId: selectedClass,
      date: selectedDate,
      records: attendanceRecords,
    });
  };

  const getStatusCounts = () => {
    const counts = attendanceRecords.reduce(
      (acc, record) => {
        acc[record.status]++;
        return acc;
      },
      { present: 0, absent: 0, late: 0 }
    );
    return counts;
  };

  const statusCounts = getStatusCounts();

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Mark Attendance
          </h1>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            Take attendance for your classes and track student participation
          </p>
        </div>

        {/* Class and Date Selection */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Select Class and Date
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Select Class
                </label>
                <Select value={selectedClass} onValueChange={setSelectedClass}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a class" />
                  </SelectTrigger>
                  <SelectContent>
                    {classesLoading ? (
                      <SelectItem value="loading" disabled>Loading classes...</SelectItem>
                    ) : (
                      teacherClasses?.map((cls: any) => (
                        <SelectItem key={cls.id} value={cls.id.toString()}>
                          {cls.name} ({cls.code})
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Date
                </label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary dark:bg-slate-800 dark:text-white"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {selectedClass && (
          <>
            {/* Attendance Summary */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Total Students</p>
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">
                        {attendanceRecords.length}
                      </p>
                    </div>
                    <Users className="h-8 w-8 text-blue-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Present</p>
                      <p className="text-2xl font-bold text-green-600">{statusCounts.present}</p>
                    </div>
                    <CheckCircle className="h-8 w-8 text-green-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Absent</p>
                      <p className="text-2xl font-bold text-red-600">{statusCounts.absent}</p>
                    </div>
                    <XCircle className="h-8 w-8 text-red-500" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Late</p>
                      <p className="text-2xl font-bold text-yellow-600">{statusCounts.late}</p>
                    </div>
                    <Clock className="h-8 w-8 text-yellow-500" />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Attendance Marking */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Student Attendance</CardTitle>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm" onClick={markAllPresent}>
                      Mark All Present
                    </Button>
                    <Button variant="outline" size="sm" onClick={markAllAbsent}>
                      Mark All Absent
                    </Button>
                    <Button 
                      onClick={handleSaveAttendance}
                      disabled={saveAttendanceMutation.isPending}
                      size="sm"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {saveAttendanceMutation.isPending ? 'Saving...' : 'Save Attendance'}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {studentsLoading ? (
                  <div className="text-center py-8 text-gray-500">
                    Loading students...
                  </div>
                ) : attendanceRecords.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No students found in this class
                  </div>
                ) : (
                  <div className="space-y-4">
                    {attendanceRecords.map((record, index) => (
                      <div
                        key={record.studentId}
                        className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="bg-primary/10 p-2 rounded-full">
                            <Users className="h-4 w-4 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900 dark:text-white">
                              {record.studentName}
                            </h3>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Student ID: {record.studentId}
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-4">
                          <div className="flex space-x-2">
                            <Button
                              variant={record.status === 'present' ? 'default' : 'outline'}
                              size="sm"
                              onClick={() => updateAttendanceStatus(record.studentId, 'present')}
                              className={record.status === 'present' ? 'bg-green-500 hover:bg-green-600' : ''}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Present
                            </Button>
                            <Button
                              variant={record.status === 'late' ? 'default' : 'outline'}
                              size="sm"
                              onClick={() => updateAttendanceStatus(record.studentId, 'late')}
                              className={record.status === 'late' ? 'bg-yellow-500 hover:bg-yellow-600' : ''}
                            >
                              <Clock className="h-4 w-4 mr-1" />
                              Late
                            </Button>
                            <Button
                              variant={record.status === 'absent' ? 'default' : 'outline'}
                              size="sm"
                              onClick={() => updateAttendanceStatus(record.studentId, 'absent')}
                              className={record.status === 'absent' ? 'bg-red-500 hover:bg-red-600' : ''}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Absent
                            </Button>
                          </div>
                          
                          <Badge
                            variant={
                              record.status === 'present' ? 'default' :
                              record.status === 'late' ? 'secondary' : 'destructive'
                            }
                            className={
                              record.status === 'present' ? 'bg-green-500' :
                              record.status === 'late' ? 'bg-yellow-500' : 'bg-red-500'
                            }
                          >
                            {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}