import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Navigation } from "@/components/layout/navigation";
import { LoadingOverlay, SkeletonCard, LoadingSpinner, ActionLoader } from "@/components/ui/loading";
import { useAuth } from "@/hooks/useAuth";
import { authService } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, BarChart3, Users, Calendar } from "lucide-react";

export default function TeacherDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedClass, setSelectedClass] = useState<any>(null);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: [`/api/dashboard/teacher/${user?.id}`],
    enabled: !!user?.id,
    queryFn: async () => {
      const res = await fetch(`/api/dashboard/teacher/${user?.id}`, {
        headers: authService.getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed to fetch dashboard stats");
      return res.json();
    },
  });

  const { data: classes } = useQuery({
    queryKey: ["/api/classes"],
    enabled: !!user?.id,
    queryFn: async () => {
      const res = await fetch("/api/classes", {
        headers: authService.getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed to fetch classes");
      return res.json();
    },
  });

  const { data: students } = useQuery({
    queryKey: [`/api/classes/${selectedClass?.id}/students`],
    enabled: !!selectedClass?.id,
    queryFn: async () => {
      const res = await fetch(`/api/classes/${selectedClass.id}/students`, {
        headers: authService.getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed to fetch students");
      return res.json();
    },
  });

  const markAttendanceMutation = useMutation({
    mutationFn: async ({ studentId, status }: { studentId: number; status: string }) => {
      await apiRequest("POST", "/api/attendance", {
        studentId,
        classId: selectedClass.id,
        status,
        date: new Date().toISOString(),
      });
    },
    onSuccess: () => {
      toast({
        title: "Attendance marked",
        description: "Student attendance has been recorded.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleMarkAttendance = (studentId: number, status: "present" | "absent") => {
    markAttendanceMutation.mutate({ studentId, status });
  };

  if (statsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background to-muted">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-8 animate-fade-in">
            <div className="skeleton-title" />
            <div className="skeleton-text w-1/2" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
            <SkeletonCard />
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <SkeletonCard />
            <SkeletonCard />
          </div>
        </div>
      </div>
    );
  }

  const quickActions = [
    {
      title: "Mark Attendance",
      description: "Today's classes",
      icon: Plus,
      color: "bg-blue-100 dark:bg-blue-900/20 text-blue-500",
      onClick: () => window.location.href = '/teacher/attendance',
    },
    {
      title: "View Reports",
      description: "Class analytics",
      icon: BarChart3,
      color: "bg-green-100 dark:bg-green-900/20 text-green-500",
      onClick: () => window.location.href = '/reports',
    },
    {
      title: "Manage Students",
      description: "Class roster",
      icon: Users,
      color: "bg-purple-100 dark:bg-purple-900/20 text-purple-500",
    },
    {
      title: "Schedule",
      description: "View timetable",
      icon: Calendar,
      color: "bg-yellow-100 dark:bg-yellow-900/20 text-yellow-500",
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Teacher Dashboard
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Welcome, Prof. {user?.firstName}! Manage your classes and track attendance.
          </p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <Card
                key={index}
                className="card-hover transition-all duration-300 cursor-pointer animate-scale-in"
                style={{ animationDelay: `${index * 0.1}s` }}
                onClick={action.onClick}
              >
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <div className={`${action.color} p-4 rounded-xl animate-float`} style={{ animationDelay: `${index * 0.2}s` }}>
                      <Icon className="h-7 w-7" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">
                        {action.title}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {action.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Class Selection */}
        {classes && classes.length > 0 && (
          <Card className="card-hover mb-8 animate-slide-up">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-primary" />
                Select Class for Attendance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {classes.map((cls: any, index: number) => (
                  <Button
                    key={cls.id}
                    variant={selectedClass?.id === cls.id ? "default" : "outline"}
                    onClick={() => setSelectedClass(cls)}
                    className="h-auto p-4 justify-start transition-all duration-300 hover:scale-105 animate-bounce-in"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="text-left">
                      <div className="font-medium">{cls.name}</div>
                      <div className="text-sm opacity-70">{cls.code}</div>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Attendance Marking Interface */}
        {selectedClass && students && (
          <ActionLoader isLoading={markAttendanceMutation.isPending}>
            <Card className="card-hover animate-slide-up">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Mark Attendance - {selectedClass.name}
                  {markAttendanceMutation.isPending && (
                    <LoadingSpinner size="sm" className="ml-2" />
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {students.map((student: any, index: number) => (
                    <div
                      key={student.id}
                      className="flex items-center justify-between p-4 border rounded-xl hover:shadow-md transition-all duration-300 animate-bounce-in"
                      style={{ animationDelay: `${index * 0.05}s` }}
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center text-white font-semibold animate-float" style={{ animationDelay: `${index * 0.1}s` }}>
                          <span className="text-sm">
                            {student.firstName?.[0]}{student.lastName?.[0]}
                          </span>
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900 dark:text-white">
                            {student.firstName} {student.lastName}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            ID: {student.studentId || student.id}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          size="sm"
                          onClick={() => handleMarkAttendance(student.id, "present")}
                          disabled={markAttendanceMutation.isPending}
                          className="bg-green-500 hover:bg-green-600 hover:scale-105 transition-all duration-200"
                        >
                          {markAttendanceMutation.isPending ? (
                            <LoadingSpinner size="sm" />
                          ) : (
                            "Present"
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleMarkAttendance(student.id, "absent")}
                          disabled={markAttendanceMutation.isPending}
                          className="hover:scale-105 transition-all duration-200"
                        >
                          {markAttendanceMutation.isPending ? (
                            <LoadingSpinner size="sm" />
                          ) : (
                            "Absent"
                          )}
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </ActionLoader>
        )}

        {!selectedClass && classes && classes.length > 0 && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            Select a class above to mark attendance
          </div>
        )}

        {(!classes || classes.length === 0) && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            No classes assigned
          </div>
        )}
      </div>
    </div>
  );
}
