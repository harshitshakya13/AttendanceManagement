import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Navigation } from "@/components/layout/navigation";
import { useAuth } from "@/hooks/useAuth";
import { authService } from "@/lib/auth";
import { format } from "date-fns";
import { CalendarIcon, Download, Filter, FileText, BarChart3, TrendingDown, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

interface ReportData {
  lowAttendanceStudents: Array<{
    id: number;
    name: string;
    email: string;
    department: string;
    attendanceRate: number;
    absences: number;
    classCount: number;
  }>;
  classPerformance: Array<{
    id: number;
    name: string;
    code: string;
    teacherName: string;
    enrollmentCount: number;
    avgAttendance: number;
    trend: "up" | "down" | "stable";
  }>;
  departmentSummary: Array<{
    department: string;
    totalStudents: number;
    avgAttendance: number;
    classCount: number;
    riskStudents: number;
  }>;
  attendanceTrends: Array<{
    date: string;
    totalPresent: number;
    totalAbsent: number;
    rate: number;
  }>;
}

export default function AdvancedReports() {
  const { user } = useAuth();
  const [dateRange, setDateRange] = useState<{
    from: Date | undefined;
    to: Date | undefined;
  }>({
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
    to: new Date(),
  });
  const [reportType, setReportType] = useState("overview");
  const [departmentFilter, setDepartmentFilter] = useState("all");

  const { data: reportData, isLoading } = useQuery({
    queryKey: ["/api/admin/reports", dateRange, reportType, departmentFilter],
    enabled: !!user?.id && !!dateRange.from && !!dateRange.to,
    queryFn: async () => {
      const params = new URLSearchParams({
        from: dateRange.from!.toISOString(),
        to: dateRange.to!.toISOString(),
        type: reportType,
        department: departmentFilter,
      });
      const res = await fetch(`/api/admin/reports?${params}`, {
        headers: authService.getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed to fetch report data");
      return res.json() as ReportData;
    },
  });

  const { data: departments } = useQuery({
    queryKey: ["/api/admin/departments"],
    enabled: !!user?.id,
    queryFn: async () => {
      const res = await fetch("/api/admin/departments", {
        headers: authService.getAuthHeaders(),
      });
      if (!res.ok) throw new Error("Failed to fetch departments");
      return res.json() as string[];
    },
  });

  const exportReport = (format: "csv" | "pdf" | "excel") => {
    // Implement export functionality
    console.log(`Exporting ${reportType} report as ${format}`);
  };

  const getAttendanceColor = (rate: number) => {
    if (rate >= 90) return "text-green-600 dark:text-green-400";
    if (rate >= 80) return "text-yellow-600 dark:text-yellow-400";
    return "text-red-600 dark:text-red-400";
  };

  const getAttendanceBadge = (rate: number) => {
    if (rate >= 90) return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300";
    if (rate >= 80) return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300";
    return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300";
  };

  const getTrendIcon = (trend: "up" | "down" | "stable") => {
    switch (trend) {
      case "up": return "↗️";
      case "down": return "↘️";
      default: return "→";
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
        <Navigation />
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Generating reports...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
              Advanced Reports
            </h1>
            <p className="text-gray-600 dark:text-gray-400 mt-2">
              Comprehensive attendance analytics and performance insights
            </p>
          </div>
          
          <div className="flex items-center gap-2 mt-4 sm:mt-0">
            <Button variant="outline" onClick={() => exportReport("csv")}>
              <Download className="h-4 w-4 mr-2" />
              CSV
            </Button>
            <Button variant="outline" onClick={() => exportReport("excel")}>
              <Download className="h-4 w-4 mr-2" />
              Excel
            </Button>
            <Button variant="outline" onClick={() => exportReport("pdf")}>
              <Download className="h-4 w-4 mr-2" />
              PDF
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                  Date Range
                </label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dateRange && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange?.from ? (
                        dateRange.to ? (
                          <>
                            {format(dateRange.from, "LLL dd, y")} -{" "}
                            {format(dateRange.to, "LLL dd, y")}
                          </>
                        ) : (
                          format(dateRange.from, "LLL dd, y")
                        )
                      ) : (
                        <span>Pick a date</span>
                      )}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      initialFocus
                      mode="range"
                      defaultMonth={dateRange?.from}
                      selected={dateRange}
                      onSelect={setDateRange}
                      numberOfMonths={2}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                  Report Type
                </label>
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="overview">Overview Report</SelectItem>
                    <SelectItem value="attendance">Attendance Detail</SelectItem>
                    <SelectItem value="performance">Class Performance</SelectItem>
                    <SelectItem value="risk">Risk Analysis</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                  Department
                </label>
                <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    {departments?.map((dept) => (
                      <SelectItem key={dept} value={dept}>{dept}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button className="w-full">
                  <Filter className="h-4 w-4 mr-2" />
                  Apply Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Department Summary */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Department Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {reportData?.departmentSummary.map((dept, index) => (
                <div key={index} className="p-4 border rounded-lg dark:border-gray-700">
                  <h3 className="font-medium text-gray-900 dark:text-white mb-2">
                    {dept.department}
                  </h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Students:</span>
                      <span className="font-medium">{dept.totalStudents}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Classes:</span>
                      <span className="font-medium">{dept.classCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">Avg Attendance:</span>
                      <span className={`font-medium ${getAttendanceColor(dept.avgAttendance)}`}>
                        {dept.avgAttendance.toFixed(1)}%
                      </span>
                    </div>
                    {dept.riskStudents > 0 && (
                      <div className="flex justify-between items-center">
                        <span className="text-gray-600 dark:text-gray-400">At Risk:</span>
                        <Badge variant="destructive" className="text-xs">
                          {dept.riskStudents} students
                        </Badge>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Reports Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Low Attendance Students */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-500" />
                Students At Risk (Below 80% Attendance)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {reportData?.lowAttendanceStudents.length ? (
                <div className="space-y-3">
                  {reportData.lowAttendanceStudents.map((student) => (
                    <div key={student.id} className="flex items-center justify-between p-3 border rounded-lg dark:border-gray-700">
                      <div>
                        <h3 className="font-medium text-gray-900 dark:text-white">
                          {student.name}
                        </h3>
                        <p className="text-xs text-gray-600 dark:text-gray-400">
                          {student.department} • {student.classCount} classes
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge className={getAttendanceBadge(student.attendanceRate)}>
                          {student.attendanceRate.toFixed(1)}%
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1">
                          {student.absences} absences
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-gray-500 py-4">
                  No students with low attendance found.
                </p>
              )}
            </CardContent>
          </Card>

          {/* Class Performance */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingDown className="h-5 w-5 text-blue-500" />
                Class Performance Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {reportData?.classPerformance.map((classItem) => (
                  <div key={classItem.id} className="flex items-center justify-between p-3 border rounded-lg dark:border-gray-700">
                    <div>
                      <h3 className="font-medium text-gray-900 dark:text-white">
                        {classItem.name}
                      </h3>
                      <p className="text-xs text-gray-600 dark:text-gray-400">
                        {classItem.code} • {classItem.teacherName} • {classItem.enrollmentCount} students
                      </p>
                    </div>
                    <div className="text-right flex items-center gap-2">
                      <span className="text-lg">{getTrendIcon(classItem.trend)}</span>
                      <div>
                        <div className={`font-medium ${getAttendanceColor(classItem.avgAttendance)}`}>
                          {classItem.avgAttendance.toFixed(1)}%
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Quick Report Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button variant="outline" className="h-20 flex-col gap-2">
                <FileText className="h-6 w-6" />
                <span>Monthly Summary</span>
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2">
                <AlertTriangle className="h-6 w-6" />
                <span>Risk Assessment</span>
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2">
                <BarChart3 className="h-6 w-6" />
                <span>Performance Trends</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}