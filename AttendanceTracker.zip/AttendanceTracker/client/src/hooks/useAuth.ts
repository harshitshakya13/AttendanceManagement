import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { authService, type User, type AuthResponse, type LoginRequest, type RegisterRequest } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

export function useAuth() {
  const { data: user, isLoading } = useQuery({
    queryKey: ["/api/auth/me"],
    enabled: authService.isAuthenticated(),
    retry: false,
    queryFn: async () => {
      const res = await fetch("/api/auth/me", {
        headers: authService.getAuthHeaders(),
      });
      
      if (!res.ok) {
        if (res.status === 401) {
          authService.logout();
          return null;
        }
        throw new Error("Failed to fetch user");
      }
      
      const userData = await res.json();
      authService.setUser(userData);
      return userData;
    },
  });

  const isAuthenticated = authService.isAuthenticated() && !!user;

  return {
    user,
    isLoading,
    isAuthenticated,
  };
}

export function useLogin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (credentials: LoginRequest): Promise<AuthResponse> => {
      const res = await apiRequest("POST", "/api/auth/login", credentials);
      return await res.json();
    },
    onSuccess: (data) => {
      authService.setToken(data.token);
      authService.setUser(data.user);
      queryClient.setQueryData(["/api/auth/me"], data.user);
      
      toast({
        title: "Login successful",
        description: "Welcome back!",
      });
    },
    onError: (error) => {
      toast({
        title: "Login failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useRegister() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (userData: RegisterRequest): Promise<AuthResponse> => {
      const res = await apiRequest("POST", "/api/auth/register", userData);
      return await res.json();
    },
    onSuccess: (data) => {
      authService.setToken(data.token);
      authService.setUser(data.user);
      queryClient.setQueryData(["/api/auth/me"], data.user);
      
      toast({
        title: "Registration successful",
        description: "Welcome to AttendanceHub!",
      });
    },
    onError: (error) => {
      toast({
        title: "Registration failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useLogout() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async () => {
      // Call logout API endpoint if exists, or just clear local storage
      authService.removeToken();
      await queryClient.clear();
      return Promise.resolve();
    },
    onSuccess: () => {
      toast({
        title: "Logged out successfully",
        description: "See you next time!",
      });
      // Delay redirect to show toast
      setTimeout(() => {
        window.location.href = '/';
      }, 1000);
    },
    onError: () => {
      // Even if logout fails, clear local data and redirect
      authService.removeToken();
      queryClient.clear();
      window.location.href = '/';
    },
  });
}
