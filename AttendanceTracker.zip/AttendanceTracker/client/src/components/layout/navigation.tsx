import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { useTheme } from "@/components/ui/theme-provider";
import { useAuth, useLogout } from "@/hooks/useAuth";
import { Calendar, Menu, Sun, Moon, LogOut, User, Clock, Timer, Loader2 } from "lucide-react";

interface NavigationProps {
  onLoginClick?: () => void;
}

export function Navigation({ onLoginClick }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [isClockedIn, setIsClockedIn] = useState(false);
  const [sessionTime, setSessionTime] = useState(0);
  const [timerInterval, setTimerInterval] = useState<NodeJS.Timeout | null>(null);
  const { theme, setTheme } = useTheme();
  const { user, isAuthenticated } = useAuth();
  const logoutMutation = useLogout();

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  // Clock in/out functionality for students
  useEffect(() => {
    if (user?.role === 'student') {
      const clockInTime = localStorage.getItem('clockInTime');
      if (clockInTime) {
        setIsClockedIn(true);
        // Calculate initial elapsed time
        const now = Date.now();
        const elapsed = Math.floor((now - parseInt(clockInTime)) / 1000);
        setSessionTime(elapsed);
        
        // Set up timer to update every second
        const interval = setInterval(() => {
          const currentTime = Date.now();
          const newElapsed = Math.floor((currentTime - parseInt(clockInTime)) / 1000);
          setSessionTime(newElapsed);
        }, 1000);
        
        setTimerInterval(interval);
        return () => {
          clearInterval(interval);
          setTimerInterval(null);
        };
      } else {
        setIsClockedIn(false);
        setSessionTime(0);
      }
    }
    
    return () => {
      if (timerInterval) {
        clearInterval(timerInterval);
        setTimerInterval(null);
      }
    };
  }, [user]);

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleClockIn = () => {
    // Clear any existing timer first
    if (timerInterval) {
      clearInterval(timerInterval);
    }
    
    const now = Date.now();
    localStorage.setItem('clockInTime', now.toString());
    setIsClockedIn(true);
    setSessionTime(0);
    
    // Start the timer immediately
    const interval = setInterval(() => {
      const currentTime = Date.now();
      const elapsed = Math.floor((currentTime - now) / 1000);
      setSessionTime(elapsed);
    }, 1000);
    
    setTimerInterval(interval);
  };

  const handleClockOut = () => {
    // Clear the timer
    if (timerInterval) {
      clearInterval(timerInterval);
      setTimerInterval(null);
    }
    
    localStorage.removeItem('clockInTime');
    setIsClockedIn(false);
    setSessionTime(0);
  };

  const handleLogout = () => {
    logoutMutation.mutate();
    setIsOpen(false);
  };

  const navLinks = [
    { href: "#home", label: "Home" },
    { href: "#features", label: "Features" },
    { href: "#about", label: "About" },
    { href: "#contact", label: "Contact" },
  ];

  return (
    <nav className="bg-white dark:bg-slate-800 shadow-sm border-b border-gray-200 dark:border-slate-700 sticky top-0 z-50 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-3">
            <div className="bg-primary p-2 rounded-lg">
              <Calendar className="text-primary-foreground h-5 w-5" />
            </div>
            <span className="text-xl font-bold text-gray-900 dark:text-white">
              AttendanceHub
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            {!isAuthenticated && navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-gray-700 dark:text-gray-300 hover:text-primary dark:hover:text-primary transition-colors"
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="rounded-lg"
            >
              {theme === "light" ? (
                <Sun className="h-5 w-5 text-yellow-500" />
              ) : (
                <Moon className="h-5 w-5 text-slate-400" />
              )}
            </Button>

            {isAuthenticated ? (
              <div className="flex items-center space-x-2">
                {/* Clock In/Out for Students */}
                {user?.role === 'student' && (
                  <div className="flex items-center space-x-2">
                    {isClockedIn ? (
                      <>
                        <Badge variant="default" className="bg-green-500 text-white">
                          <Clock className="h-3 w-3 mr-1" />
                          {formatTime(sessionTime)}
                        </Badge>
                        <Button variant="outline" onClick={handleClockOut} size="sm">
                          <Timer className="h-4 w-4 mr-1" />
                          Clock Out
                        </Button>
                      </>
                    ) : (
                      <Button variant="default" onClick={handleClockIn} size="sm">
                        <Clock className="h-4 w-4 mr-1" />
                        Clock In
                      </Button>
                    )}
                  </div>
                )}
                
                <span className="hidden sm:block text-sm text-gray-600 dark:text-gray-400">
                  Welcome, {user?.firstName}!
                </span>
                <Button 
                  variant="destructive" 
                  onClick={handleLogout} 
                  size="sm"
                  disabled={logoutMutation.isPending}
                >
                  {logoutMutation.isPending ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <LogOut className="h-4 w-4 mr-2" />
                  )}
                  {logoutMutation.isPending ? 'Logging out...' : 'Logout'}
                </Button>
              </div>
            ) : (
              <Button onClick={onLoginClick}>Login</Button>
            )}

            {/* Mobile menu button */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <div className="flex flex-col space-y-4 mt-8">
                  {!isAuthenticated && navLinks.map((link) => (
                    <a
                      key={link.href}
                      href={link.href}
                      className="text-gray-700 dark:text-gray-300 hover:text-primary transition-colors py-2"
                      onClick={() => setIsOpen(false)}
                    >
                      {link.label}
                    </a>
                  ))}
                  
                  {isAuthenticated && (
                    <div className="border-t pt-4">
                      <div className="flex items-center space-x-3 mb-4">
                        <div className="bg-primary/10 p-2 rounded-full">
                          <User className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">
                            {user?.firstName} {user?.lastName}
                          </p>
                          <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                            {user?.role}
                          </p>
                        </div>
                      </div>
                      <Button 
                        variant="destructive" 
                        onClick={handleLogout}
                        className="w-full"
                      >
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </Button>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
}
