import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import { useAuth } from "@/hooks/useAuth";
import Landing from "@/pages/landing";
import StudentDashboard from "@/pages/dashboard/student-dashboard";
import TeacherDashboard from "@/pages/dashboard/teacher-dashboard";
import AdminDashboard from "@/pages/dashboard/admin-dashboard";
import UserManagement from "@/pages/dashboard/user-management";
import SystemAnalytics from "@/pages/dashboard/system-analytics";
import AdvancedReports from "@/pages/dashboard/advanced-reports";
import StudentAttendance from "@/pages/dashboard/student-attendance";
import StudentSchedule from "@/pages/dashboard/student-schedule";
import TeacherAttendance from "@/pages/dashboard/teacher-attendance";
import Reports from "@/pages/reports";
import Profile from "@/pages/profile";
import AccessDenied from "@/pages/access-denied";
import NotFound from "@/pages/not-found";

function ProtectedRoute({ 
  children, 
  allowedRoles 
}: { 
  children: React.ReactNode; 
  allowedRoles: string[];
}) {
  const { user, isLoading, isAuthenticated } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  if (user && !allowedRoles.includes(user.role)) {
    return <AccessDenied />;
  }

  return <>{children}</>;
}

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/" component={Landing} />
      
      {/* Dashboard Routes */}
      <Route path="/dashboard/student">
        <ProtectedRoute allowedRoles={['student']}>
          <StudentDashboard />
        </ProtectedRoute>
      </Route>
      
      <Route path="/student/attendance">
        <ProtectedRoute allowedRoles={['student']}>
          <StudentAttendance />
        </ProtectedRoute>
      </Route>
      
      <Route path="/student/schedule">
        <ProtectedRoute allowedRoles={['student']}>
          <StudentSchedule />
        </ProtectedRoute>
      </Route>
      
      <Route path="/dashboard/teacher">
        <ProtectedRoute allowedRoles={['teacher']}>
          <TeacherDashboard />
        </ProtectedRoute>
      </Route>
      
      <Route path="/teacher/attendance">
        <ProtectedRoute allowedRoles={['teacher']}>
          <TeacherAttendance />
        </ProtectedRoute>
      </Route>
      
      <Route path="/dashboard/admin">
        <ProtectedRoute allowedRoles={['admin']}>
          <AdminDashboard />
        </ProtectedRoute>
      </Route>

      <Route path="/admin/users">
        <ProtectedRoute allowedRoles={['admin']}>
          <UserManagement />
        </ProtectedRoute>
      </Route>

      <Route path="/admin/analytics">
        <ProtectedRoute allowedRoles={['admin']}>
          <SystemAnalytics />
        </ProtectedRoute>
      </Route>

      <Route path="/admin/reports">
        <ProtectedRoute allowedRoles={['admin']}>
          <AdvancedReports />
        </ProtectedRoute>
      </Route>

      {/* Auto redirect to appropriate dashboard based on role */}
      <Route path="/dashboard">
        {isAuthenticated && user ? (
          <Redirect to={`/dashboard/${user.role}`} />
        ) : (
          <Redirect to="/" />
        )}
      </Route>

      {/* Other Protected Routes */}
      <Route path="/reports">
        <ProtectedRoute allowedRoles={['teacher', 'admin']}>
          <Reports />
        </ProtectedRoute>
      </Route>

      <Route path="/profile">
        <ProtectedRoute allowedRoles={['student', 'teacher', 'admin']}>
          <Profile />
        </ProtectedRoute>
      </Route>

      <Route path="/access-denied" component={AccessDenied} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="attendance-theme">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
